from azure.cognitiveservices.vision.customvision.training import CustomVisionTrainingClient
from azure.cognitiveservices.vision.customvision.prediction import CustomVisionPredictionClient
from azure.cognitiveservices.vision.customvision.training.models import ImageFileCreateBatch, ImageFileCreateEntry, Region
from msrest.authentication import ApiKeyCredentials
import os, time, uuid
import datetime
import pandas as pd
#import os
import glob
import shutil

# Replace with valid values

#Praveen endpoints
ENDPOINT = "https://centralindia.api.cognitive.microsoft.com/"
training_key = "548d0ec5748144879759af20b0ac09ea"
prediction_key = "548d0ec5748144879759af20b0ac09ea"
prediction_resource_id = "/subscriptions/dab7d330-8ff6-4fd3-bc20-06cf519181b9/resourceGroups/mygroup/providers/Microsoft.CognitiveServices/accounts/mygroup"
publish_iteration_name = "classifyModel"


"""
##shiva end points

ENDPOINT = "https://southcentralus.api.cognitive.microsoft.com/"
training_key = "9e79e589b2904dfbaafe1264077e5cb5"
prediction_key = "9e79e589b2904dfbaafe1264077e5cb5"
prediction_resource_id = "/subscriptions/1e657171-4c24-4506-b54a-bfac1954cdcb/resourceGroups/kssvphackathon/providers/Microsoft.CognitiveServices/accounts/kssvphackathoncustomvision"
publish_iteration_name = "classifyModel"
"""
"""
#Ashwar end points
private static string trainingEndpoint = "https://illuminaticustomvision.cognitiveservices.azure.com/";
private static string trainingKey = "e2903b6c583f492992016dc830c6a9cd";
// You can obtain these values from the Keys and Endpoint page for your Custom Vision Prediction resource in the Azure Portal.
private static string predictionEndpoint = "https://illuminaticustomvi-prediction.cognitiveservices.azure.com/";
private static string predictionKey = "b4e86ab713e04f8ab9a6bfa3bbf76b6a";
// You can obtain this value from the Properties page for your Custom Vision Prediction resource in the Azure Portal. See the "Resource ID" field. This typically has a value such as:
// /subscriptions/<your subscription ID>/resourceGroups/<your resource group>/providers/Microsoft.CognitiveServices/accounts/<your Custom Vision prediction resource name>
private static string predictionResourceId = "/subscriptions/c890ad9a-9348-44ff-a405-1f4be32c6c5d/resourceGroups/RGAsh/providers/Microsoft.CognitiveServices/accounts/IlluminatiCustomVi-Prediction";

"""

credentials = ApiKeyCredentials(in_headers={"Training-key": training_key})
trainer = CustomVisionTrainingClient(ENDPOINT, credentials)

# Create a new project
print ("Creating project...")
#project_name = uuid.uuid4()
project = trainer.create_project("hackathon8hrs",classification_type='Multiclass')

df = pd.read_excel(r"C:\Users\maddikuntla.p.kumar\Downloads\TrainDataSheet.xlsx")

print(df.head())
print(df.__len__)

print(df.ModelName.unique())

# Make two tags in the new project
# Dog_tag = trainer.create_tag(project.id, "Dogs")
# Cat_tag = trainer.create_tag(project.id, "Cats")

tags={}
for tag in df.ModelName.unique():
    tags[tag]=trainer.create_tag(project.id,tag )



base_image_location=os.getcwd()+"\static\images\myTrainingData"

print("Adding images...")

image_list = []
for folder in os.listdir(base_image_location):
    folderloc=base_image_location+'/'+folder+'/'
    for listimages in os.listdir(folderloc):
        with open(os.path.join(folderloc, listimages), "rb") as image_contents:
            print(listimages)
            image_list.append(ImageFileCreateEntry(name=listimages, contents=image_contents.read(), tag_ids=[tags[folder].id]))

# for image_num in range(1, 10):
#     file_name = "dog{}.jpg".format(image_num)
#     with open(os.path.join (base_image_location, "Dog", file_name), "rb") as image_contents:
#         image_list.append(ImageFileCreateEntry(name=file_name, contents=image_contents.read(), tag_ids=[Cat_tag.id]))

# for image_num in range(1, 8):
#     file_name = "cat{}.jpg".format(image_num)
#     with open(os.path.join (base_image_location, "cat", file_name), "rb") as image_contents:
#         image_list.append(ImageFileCreateEntry(name=file_name, contents=image_contents.read(), tag_ids=[Dog_tag.id]))


for i in range(0,len(image_list),64):
    batch = image_list[i:i+64]
    trainer.create_images_from_files(project.id, ImageFileCreateBatch(images=batch))

# upload_result = trainer.create_images_from_files(project.id, ImageFileCreateBatch(images=image_list))
#
# if not upload_result.is_batch_successful:
#     print("Image batch upload failed.")
#     for image in upload_result.images:
#         print("Image status: ", image.status)
#     exit(-1)


##training
print ("Training...")
starttime=time.time()
iteration = trainer.train_project(project.id,training_type='Advanced',reserved_budget_in_hours=8)
while (iteration.status != "Completed"):
    iteration = trainer.get_iteration(project.id, iteration.id)
    print ("Training status: " + iteration.status)
    print ("Waiting 10 seconds...")
    #time.sleep(10)
endtime=time.time()

# The iteration is now trained. Publish it to the project endpoint
trainer.publish_iteration(project.id, iteration.id, publish_iteration_name, prediction_resource_id)
perfomance_metrics=trainer.get_iteration_performance(project.id, iteration.id)
print ("Done!")

# prediction_credentials = ApiKeyCredentials(in_headers={"Prediction-key": prediction_key})
# predictor = CustomVisionPredictionClient(ENDPOINT, prediction_credentials)
# project_id=project.id
# with open(base_image_location + "\Cat\cat11.jpg", "rb") as image_contents:
#     results = predictor.classify_image(
#         project_id, publish_iteration_name, image_contents.read())
# # Display the results.
#     for prediction in results.predictions:
#         print("\t" + prediction.tag_name +
#               ": {0:.2f}%".format(prediction.probability * 100))
#     print(project.id)
#
