import os

from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def myfun(request):
    return render(request,"home.html",{'name':'kumar'})

def index(request):
    return render(request,'index.html')

def existingModelFun(request):
    user = request.user
    category = request.GET.get('category')
    if category == None:
        photos = Photo.objects.filter(category__user=user)
    else:
        photos = Photo.objects.filter(
            category__name=category, category__user=user)

    categories = Category.objects.filter(user=user)
    context = {'categories': categories, 'photos': photos}

    return render(request,'existingmodel.html',context)

def retrainModel(request):
    user = request.user
    category = request.GET.get('category')
    if category == None:
        photos = Photo.objects.filter(category__user=user)
    else:
        photos = Photo.objects.filter(
            category__name=category, category__user=user)

    categories = Category.objects.filter(user=user)
    context = {'categories': categories, 'photos': photos}

    return render(request,'retrainExistingModel.html',context)

def trainModel(request):
    return render(request,'train.html')

def testModel(request):
    return render(request,'test.html')


from django.shortcuts import render, redirect
from .models import Category, Photo
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import CustomUserCreationForm
# Create your views here.


def loginUser(request):
    page = 'login'
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('createmodel')

    return render(request, 'login_register.html', {'page': page})

#def home(request):
#    return render(request,"photos/home.html")

#def index(request):
#    return render(request,"photos/index.html")


def logoutUser(request):
    logout(request)
    return redirect('login')


def registerUser(request):
    page = 'register'
    form = CustomUserCreationForm()

    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()

            if user is not None:
                login(request, user)
                return redirect('createmodel')

    context = {'form': form, 'page': page}
    return render(request, 'login_register.html', context)

@login_required(login_url='login')
def createmodel(request):
    user = request.user
    category = request.GET.get('category')
    if category == None:
        photos = Photo.objects.filter(category__user=user)
    else:
        photos = Photo.objects.filter(
            category__name=category, category__user=user)

    categories = Category.objects.filter(user=user)
    context = {'categories': categories, 'photos': photos}
    return render(request, 'gallery.html', context)


@login_required(login_url='login')
def viewPhoto(request, pk):
    photo = Photo.objects.get(id=pk)
    return render(request, 'photo.html', {'photo': photo})


@login_required(login_url='login')
def addPhoto(request):
    user = request.user
    #print(request.headers['Referer'])

    categories = user.category_set.all()

    if request.method == 'POST':
        data = request.POST
        images = request.FILES.getlist('images')

        if data['category'] != 'none':
            category = Category.objects.get(id=data['category'])
        elif data['category_new'] != '':
            category, created = Category.objects.get_or_create(
                user=user,
                name=data['category_new'])
        else:
            category = None

        for image in images:
            photo = Photo.objects.create(
                category=category,
                #description=data['description'],
                image=image,
            )

        return redirect('createmodel')

    context = {'categories': categories}
    return render(request, 'add.html', context)

@login_required(login_url='login')
def addRetrainPhoto(request):
    user = request.user
    #print(request.headers['Referer'])

    categories = user.category_set.all()

    if request.method == 'POST':
        data = request.POST
        images = request.FILES.getlist('images')

        if data['category'] != 'none':
            category = Category.objects.get(id=data['category'])
        elif data['category_new'] != '':
            category, created = Category.objects.get_or_create(
                user=user,
                name=data['category_new'])
        else:
            category = None

        for image in images:
            photo = Photo.objects.create(
                category=category,
                #description=data['description'],
                image=image,
            )

        return redirect('retrainModel')

    context = {'categories': categories}
    return render(request, 'addRetrain.html', context)




@login_required(login_url='login')
def addTestPhoto(request):
    user = request.user

    categories = user.category_set.all()

    if request.method == 'POST':
        data = request.POST
        images = request.FILES.getlist('images')

        if data['category'] != 'none':
            category = Category.objects.get(id=data['category'])
        elif data['category_new'] != '':
            category, created = Category.objects.get_or_create(
                user=user,
                name=data['category_new'])
        else:
            category = None

        for image in images:
            photo = Photo.objects.create(
                category=category,
                #description=data['description'],
                image=image,
            )

        return redirect('testMetric')

    context = {'categories': categories}
    return render(request, 'addTest.html', context)


def loading(request):
    return render(request,'LoadingPage.html')

def retrainGallery(request):
    user = request.user
    category = request.GET.get('category')
    if category == None:
        photos = Photo.objects.filter(category__user=user)
    else:
        photos = Photo.objects.filter(
            category__name=category, category__user=user)

    categories = Category.objects.filter(user=user)
    context = {'categories': categories, 'photos': photos}
    return  render(request,'retrainGallery.html',context)

def resultIndex(request):
    return render(request,'resultindex.html')

def testMetric(request):
    return render(request,'testMetric.html')

def response(request):
    return render(request,'response.html')

def publish(request):
    return  render(request,'publish.html')