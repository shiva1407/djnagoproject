from django.urls import path

from . import views

urlpatterns=[
    #shivas urls
    path('login', views.loginUser, name="login"),
    path('logout', views.logoutUser, name="logout"),
    path('register/', views.registerUser, name="register"),

    path('createmodel', views.createmodel, name='createmodel'),
    path('photo/<str:pk>/', views.viewPhoto, name='photo'),
    path('add/', views.addPhoto, name='add'),
    path('addtest/', views.addTestPhoto, name='addtest'),

    path('loading',views.loading,name='loading'),
    path('train/',views.trainModel ,name='train'),
    path('retrainModel/', views.retrainGallery, name='retrainModel'),
    path('test', views.testModel, name='test'),
    path('publish',views.publish,name='publish'),
    path('response',views.response,name='response'),
    #end
    path('result/',views.resultIndex,name='result'),
    path('testMetric/',views.testMetric,name='testMetric'),
    path("retrain",views.retrainModel,name="retrain"),
    path("existingmodel",views.existingModelFun,name="existingmodel"),
    path("home",views.myfun,name='home'),
    path("",views.index,name='index'),
    path('addRetrain/',views.addRetrainPhoto,name='addRetrain'),

]