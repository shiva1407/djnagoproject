import pandas as pd
import os
import glob
import shutil

df = pd.read_excel(r"C:\Users\maddikuntla.p.kumar\Downloads\TrainDataSheet.xlsx")

print(df.head())
print(df.__len__)

print(df.ModelName.unique())

dfUnique = df.ModelName.unique()

root_path = r'C:\Users\maddikuntla.p.kumar\Desktop\pyCharmProjects\djangodemoproject\static\images'

# for x in dfUnique:
#     print(x)
#     path = os.path.join(root_path, x)
#     os.mkdir(path)
#
#
# src_dir = "your/source/dir"
# dst_dir = "your/destination/dir"
# for jpgfile in glob.iglob(os.path.join(src_dir, "*.jpg")):
#     shutil.copy(jpgfile, dst_dir)

for index, CorrColumnrow in df.iterrows():
    print(CorrColumnrow['ModelName'], CorrColumnrow['ImagePath'])
    src_dir = r"C:/Users/maddikuntla.p.kumar/Downloads/OneDrive_1_8-2-2021/Car_Identification/"
    src_dir = os.path.join(src_dir, CorrColumnrow['ImagePath'].replace("./", ""))
    dst_dir = r"C:\Users\maddikuntla.p.kumar\Desktop\pyCharmProjects\djangodemoproject\static\images\myTrainingData"
    dst_dir = os.path.join(dst_dir, CorrColumnrow['ModelName'])
    shutil.copy(src_dir, dst_dir)
    print(CorrColumnrow['ModelName'], CorrColumnrow['ImagePath'])